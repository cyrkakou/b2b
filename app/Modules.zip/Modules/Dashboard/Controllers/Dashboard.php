<?php
namespace App\Modules\Dashboard\Controllers;
use App\Controllers\IbemsController;

class Dashboard extends IbemsController {
    private $role;

    function __construct()
    {
        parent::__construct();
        is_protected();
        $this->role = get_user_info('role_code');
        $config = config('App');
        add_js(null,"https://maps.googleapis.com/maps/api/js?key={$config->google_map_key}&libraries=places,geometry");
        self::set_data('subheader',false);
    }
    public function index()
    {
        self::add_data('content',view('App\Modules\Dashboard\Views\index',self::get_data()));
        return view('backend/layout',self::get_data());
    }
    public function geojson(){
        $promotions = db('promotions')
            ->join('promoteurs','promoteurs.promoteurID = promotions.promoteurID','left')
            ->join('settings_villes','settings_villes.villeID = promotions.villeID','left')
            ->get()
            ->getResult();
        foreach($promotions as $promotion){
            if($rs = db('promotions_gps')
                ->where('promotionID',$promotion->promotionID)
                ->get()){
                if($rs->getNumRows() > 0){
                    $coordinates = [];
                    foreach ($rs->getResult() as $k=>$point)
                    {
                        $longitude = str_replace(',','.',$point->latitude);
                        $latitude = str_replace(',','.',$point->longitude);
                        $p[$k] = [doubleval($latitude), doubleval($longitude)];
                        $coordinates[] = [doubleval($latitude), doubleval($longitude)];
                    }
                    $coordinates[] = $p[0];

                    $features[] = [
                        "type"=>"Feature",
                        "geometry"=>[
                            "type"=>"Polygon",
                            "coordinates"=> [$coordinates]
                        ],
                        "properties"=>[
                            "promotionID"=>intval($promotion->promotionID),
                            "promoteurID"=>intval($promotion->promoteurID),
                            "ville"=>$promotion->villeLibelle,
                            "libelle"=>$promotion->libelle,
                            "date_deb"=>(!is_null($promotion->date_deb)?$promotion->date_deb:""),
                            "superficie"=>doubleval($promotion->superficie),
                            "nombre_logement"=>doubleval($promotion->nombre_logement),
                            "standing"=>(!is_null($promotion->standing)?$promotion->standing:""),
                            "avancement"=>doubleval($promotion->avancement),
                            "prix"=>doubleval($promotion->prix),
                        ]
                    ];
                }
            }
        }

        /*
         *                         "properties"=>[
                            "promotionID"=>$promotion->promotionID,
                            "promoteurID"=>$promotion->promoteurID,
                            "villeID"=>$promotion->villeLibelle,
                            "libelle"=>$promotion->libelle,
                            "date_deb"=>(!is_null($promotion->date_deb)?$promotion->date_deb:""),
                            "superficie"=>doubleval($promotion->superficie),
                            "nombre_logement"=>doubleval($promotion->nombre_logement),
                            "standing"=>(!is_null($promotion->standing)?$promotion->standing:""),
                            "avancement"=>doubleval($promotion->avancement),
                            "prix"=>doubleval($promotion->prix),
                        ]
         */

        $map = [
            "type"=>"FeatureCollection",
            "features"=>$features
        ];
        header('Content-Type: application/json');
        echo json_encode($map, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit(0);
        return json_encode($map,JSON_NUMERIC_CHECK);
    }
    public function geopoint(){
        $promotions = db('promotions')
            ->join('promoteurs','promoteurs.promoteurID = promotions.promoteurID','left')
            ->join('settings_villes','settings_villes.villeID = promotions.villeID','left')
            ->get()
            ->getResult();
        foreach($promotions as $promotion){
            if($rs = db('promotions_gps')
                ->where('promotionID',$promotion->promotionID)
                ->get()){
                if($rs->getNumRows() > 0){
                    $coordinates = [];
                    foreach ($rs->getResult() as $k=>$point)
                    {
                        $longitude = str_replace(',','.',$point->latitude);
                        $latitude = str_replace(',','.',$point->longitude);
                        $p[$k] = [doubleval($latitude), doubleval($longitude)];
                        $plot = [doubleval($latitude), doubleval($longitude)];
                        $coordinates[] = [doubleval($latitude), doubleval($longitude)];
                        $features[] = [
                            "type"=>"Feature",
                            "geometry"=>[
                                "type"=>"Point",
                                "coordinates"=> $plot
                            ],
                            "properties"=>[
                                "promotionID"=>intval($promotion->promotionID),
                                "promoteurID"=>intval($promotion->promoteurID),
                                "ville"=>$promotion->villeLibelle,
                                "promoteur"=>intval($promotion->raison_sociale),
                                "promotion"=>$promotion->libelle,
                                "date_deb"=>(!is_null($promotion->date_deb)?$promotion->date_deb:""),
                                "superficie"=>doubleval($promotion->superficie),
                                "nombre_logement"=>doubleval($promotion->nombre_logement),
                                "standing"=>(!is_null($promotion->standing)?$promotion->standing:""),
                                "avancement"=>doubleval($promotion->avancement),
                                "prix"=>doubleval($promotion->prix),
                                "label"=>intval($point->gpsID),
                                "title"=>$promotion->libelle,
                            ]
                        ];
                    }
                    //Polygon
                    $coordinates[] = $p[0];
                    $features[] = [
                        "type"=>"Feature",
                        "geometry"=>[
                            "type"=>"Polygon",
                            "coordinates"=> [$coordinates]
                        ],
                        "properties"=>[
                            "label"=>($promotion->libelle),
                            "title"=>($promotion->libelle),
                            "promotionID"=>intval($promotion->promotionID),
                            "promoteurID"=>intval($promotion->promoteurID),
                            "ville"=>$promotion->villeLibelle,
                            "promoteur"=>intval($promotion->raison_sociale),
                            "promotion"=>$promotion->libelle,
                            "date_deb"=>(!is_null($promotion->date_deb)?$promotion->date_deb:""),
                            "superficie"=>doubleval($promotion->superficie),
                            "nombre_logement"=>doubleval($promotion->nombre_logement),
                            "standing"=>(!is_null($promotion->standing)?$promotion->standing:""),
                            "avancement"=>doubleval($promotion->avancement),
                            "prix"=>doubleval($promotion->prix),
                        ]
                    ];

                }
            }
        }

        $map = [
            "type"=>"FeatureCollection",
            "features"=>$features
        ];
        header('Content-Type: application/json');
        echo json_encode($map, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit(0);
        return json_encode($map,JSON_NUMERIC_CHECK);
    }
    public function _index()
    {
        if (strtolower($this->role) === 'admin' || strtolower($this->role) === 'root') {
            return view('backend/layout', self::get_data());
        } elseif (strtolower($this->role) === 'hopital_agent'){
            return redirect()->to('hopital/dashboard');
        } else {
            return redirect()->to($this->role . '/dashboard');
        }
    }

}
