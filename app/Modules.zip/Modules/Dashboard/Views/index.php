<style>
    .content {
        position: relative;
    }
    .mapWrapper{
        position:relative;
        top: 0px;
        right: 0px;
        left: 0px;
        bottom: 0;
        height: auto;
    }
    #map,.mapWrapper{
        position:absolute;
        top: 0px;
        right: 0px;
        left: 0px;
        bottom: 0;
        height: auto;
    }

</style>
<div class="mapWrapper">
    <div id="map">
    </div>
</div>
