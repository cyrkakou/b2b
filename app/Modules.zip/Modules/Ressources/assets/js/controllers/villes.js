Apps.modal('#modal_ville_create',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
Apps.modal('#modal_ville_update',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        var villeid = button.data('villeid')
        modal.find('[name="primary_key"]').val(villeid)
        axios.post(BASE_URL + '/ressources/villes/do_find/' + villeid)
            .then(function (response) {
                // handle success
                $.each(response.data, function(name, value) {
                    modal.find('[name="' + name +'"]').val(value).change()
                });
            })
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
Apps.modal('#modal_ville_delete',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        modal.find('[name="primary_key"]').val(button.data('villeid'))
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
