Apps.modal('#modal_promoteur_create',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
Apps.modal('#modal_promoteur_update',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        var promoteurid = button.data('promoteurid')
        modal.find('[name="primary_key"]').val(promoteurid)
        axios.post(BASE_URL + '/ressources/promoteurs/do_find/' + promoteurid)
            .then(function (response) {
                // handle success
                $.each(response.data, function(name, value) {
                    modal.find('[name="' + name +'"]').val(value).change()
                });
            })
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
Apps.modal('#modal_promoteur_delete',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        modal.find('[name="primary_key"]').val(button.data('promoteurid'))
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
