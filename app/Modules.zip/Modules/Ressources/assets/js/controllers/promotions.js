Apps.modal('#modal_promotion_create',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
Apps.modal('#modal_promotion_update',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        var promotionid = button.data('promotionid')
        modal.find('[name="primary_key"]').val(promotionid)
        axios.post(BASE_URL + '/ressources/promotions/do_find/' + promotionid)
            .then(function (response) {
                // handle success
                $.each(response.data, function(name, value) {
                    modal.find('[name="' + name +'"]').val(value).change()
                });
            })
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
Apps.modal('#modal_promotion_delete',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        modal.find('[name="primary_key"]').val(button.data('promotionid'))
    },
    onSubmit:function (response,event) {
        location.reload()
    }
})
Apps.modal('#modal_promotion_gps',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        $('#btn_add_marker').data('promotionid',button.data('promotionid'))
        axios.post(BASE_URL + '/ressources/promotions/get_markers/' + button.data('promotionid'))
            .then(function (response) {
                $('#makers_list tbody').html('')
                $.each(response.data, function(name, row) {
                    $('#makers_list tbody').append(`
                        <tr gpsid="${ row.gpsID }">
                            <td>
                                <span>${ row.gpsID }</span>
                            </td>                        
                            <td><a href="javascript:;" class="latitude" data-toggle="modal" 
                                   data-target="#modal_update_marker" 
                                   data-gpsid="${ row.gpsID }"
                                   data-field="latitude"
                                   data-valeur="${ row.latitude }"
                                   title="modifier">${ row.latitude }</a>
                            </td>
                            <td><a href="javascript:;" class="longitude" data-toggle="modal" 
                                   data-target="#modal_update_marker" 
                                   data-gpsid="${ row.gpsID }"
                                   data-field="longitude"
                                   data-valeur="${ row.longitude }"                                   
                                   title="modifier">${ row.longitude }</a>
                                   </td>
                            <td><a href="javascript:;" class="altitude" data-toggle="modal" 
                                   data-target="#modal_update_marker" 
                                   data-gpsid="${ row.gpsID }"
                                   data-field="altitude"
                                   data-valeur="${ row.altitude }"                                     
                                   title="modifier">${ row.altitude }</a>
                            </td>
                            <td>
                                <a href="javascript:;" data-toggle="modal"  
                                   data-target="#modal_delete_marker"
                                   data-gpsid="${ row.gpsID }" 
                                   class="btn btn-xs btn-icon btn-link btn-link-danger" title="supprimer le point">
                                    <i class="far fa-trash"></i>
                                </a>
                            </td>
                        </tr>`)

                });
            })
    }
})
Apps.modal('#modal_addmarker',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        modal.find('[name="promotionID"]').val(button.data('promotionid'))
        modal.find('[name="longitude"]').val('')
        modal.find('[name="latitude"]').val('')
        modal.find('[name="altitude"]').val('')
    },
    onSubmit:function (response,callback) {
        let row = callback.fields
        $('#makers_list tbody').append(`
            <tr gpsid="${ response.gpsID }">
                <td>
                    <span>${ response.gpsID }</span>
                </td>              
                <td><a href="javascript:;" class="latitude" data-toggle="modal" 
                       data-target="#modal_update_marker" 
                       data-gpsid="${ response.gpsID }"
                       data-field="latitude"
                       data-valeur="${ row.latitude }"
                       title="modifier">${ row.latitude }</a>
                </td>
                <td><a href="javascript:;" class="longitude" data-toggle="modal" 
                       data-target="#modal_update_marker" 
                       data-gpsid="${ response.gpsID }"
                       data-field="longitude"
                       data-valeur="${ row.longitude }"                                   
                       title="modifier">${ row.longitude }</a>
                       </td>
                <td><a href="javascript:;" class="altitude" data-toggle="modal" 
                       data-target="#modal_update_marker" 
                       data-gpsid="${ response.gpsID }"
                       data-field="altitude"
                       data-valeur="${ row.altitude }"                                     
                       title="modifier">${ row.altitude }</a>
                </td>
                <td>
                    <a href="javascript:;" data-toggle="modal"  
                       data-target="#modal_delete_marker" 
                       data-gpsid="${ response.gpsID }" 
                       class="btn btn-xs btn-icon btn-link btn-link-danger" title="supprimer le point">
                        <i class="far fa-trash"></i>
                    </a>
                </td>
            </tr>`)
    }
})
Apps.modal('#modal_update_marker',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        modal.find('[name="gpsID"]').val(button.data('gpsid'))
        modal.find('[name="field"]').val(button.data('field'))
        modal.find('[name="valeur"]').val(button.data('valeur'))
    },
    onSubmit:function (response,callback) {
        let data = callback.fields
        $(`tr[gpsID = "${ data.gpsID }"]`).find(`.${ data.field }`).html(data.valeur)
    }
})
Apps.modal('#modal_delete_marker',{
    onLoad:function(modal, event){
        var button = $(event.relatedTarget)
        modal.find('[name="gpsID"]').val(button.data('gpsid'))
    },
    onSubmit:function (response,callback) {
        let data = callback.fields
        $(`tr[gpsID = "${ data.gpsID }"]`).remove()
    }
})
