$(document).ready(function (){
    var map = new GMaps({
        div: '#mapPreview',
        lat: 5.3602164,
        lng: -3.9674370999999837
    });

})
