jQuery(document).ready(function(){
    var column = 0;
    new Datagrid('#DT_Hopital',{
        responsive: true,
        searchDelay: 500,
        processing: true,
        serverSide: true,
        scrollY: "350px",
        //paging: false,
        order: [],
        columnDefs: [{
            targets:'no-sort',
            orderable: false,
        },{
            targets: -1,
            responsivePriority: -1,
            orderable: false,
            bSortable: false,
            className:'text-center',
            data: 'hopitalID',
            render: function(data, type, row, meta) {
                html = `<div class="dropdown">
                        <a href="javascript:;" class="btn btn-sm btn-light-primary btn-icon btn-icon-sm" data-toggle="dropdown">
                        <i class="ki ki-bold-more-hor"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <ul class="navi navi-hover">
                                <li class="navi-item">
                                    <a href="${BASE_URL}/ressources/hopitaux/update/${row.hopitalID}" class="navi-link">
                                        <span class="navi-icon">
                                            <i class="far fa-pencil"></i>
                                        </span>                                        
                                        <span class="navi-text text-nowrap">Mettre à jour</span>
                                    </a>
                                </li>
                                <li class="navi-item">
                                    <a href="javascript:;" data-toggle="modal"
                                       data-target="#modal_hopital_delete"
                                       data-hopitalID="${row.hopitalID}" 
                                       class="navi-link">
                                        <span class="navi-icon">
                                            <i class="far fa-trash text-danger"></i>
                                        </span>
                                        <span class="navi-text text-danger">Supprimer</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>`
                return html;
            },
        },{
            responsivePriority: -1,
            targets: column++,
            data: 'hopitalID',
            orderable: false,
            bSortable: false,
            searchable: false,
            render: function(data, type, row, meta) {
                return `<label class="checkbox checkbox-outline checkbox-outline-2x checkbox-primary checkbox-single">
                    <input name="selected[]" value="${ data }" type="checkbox" value="" class="checkable">
                    <span></span>
                    </label>`;
            }
        },{
            responsivePriority: 1,
            targets: column++,
            data: 'hopitalID',
            render: function(data, type, row, meta) {
                return row.hopitalID
            }
        },{
            responsivePriority: 1,
            targets: column++,
            data: 'hopital_raison_sociale',
            render: function(data, type, row, meta) {
                return row.hopital_raison_sociale
            }
        },{
            responsivePriority: -1,
            targets: column++,
            data: 'hopital_ville',
            render: function(data, type, row, meta) {
                return row.hopital_ville
            }
        },{
            responsivePriority: -1,
            targets: column++,
            data: 'hopital_commune',
            render: function(data, type, row, meta) {
                return row.hopital_commune
            }
        },{
            responsivePriority: 6,
            targets: column++,
            data: 'hopital_mobile',
            render: function(data, type, row, meta) {
                return phone(row.hopital_mobile,COUNTRY_CODE )
            }
        },{
            responsivePriority: 6,
            targets: column++,
            data: 'hopital_email',
            render: function(data, type, row, meta) {
                return row.hopital_email
            }
        },{
            responsivePriority: -1,
            targets: column++,
            className:'text-center',
            data: 'hopital_flag',
            render: function(data, type, row, meta) {
                return `<span class="label label-lg label-light-${ row.hopital_flag } label-inline">${ row.hopital_flag }</span>`
            }
        }]
    });
})
