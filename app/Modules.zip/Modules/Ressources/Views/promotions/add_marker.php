<div id="modal_addmarker" class="modal fade" data-backdrop="static" tabindex="-1"  aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!--begin::Form-->
            <form action="<?=base_url('ressources/promotions/add_marker'); ?>" class="validate" role="form"
                  enctype="multipart/form-data" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bolder"><?= lang('Layout.form_add_caption'); ?></h5>
                    <button type="button" class="btn btn-xs btn-icon btn-light btn-hover-primary" data-dismiss="modal" aria-label="Close">
                        <i class="ki ki-close icon-xs text-muted"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <input name="promotionID" type="hidden">
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Latitude<span
                                class="text-danger ml-2">*</span></label>
                        <input name="latitude" class="form-control double" type="text" data-validate="required"/>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Longitude<span
                                class="text-danger ml-2">*</span></label>
                        <input name="longitude" class="form-control double" type="text" data-validate="required" />
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Altitude<span
                                    class="text-danger ml-2">*</span></label>
                        <input name="altitude" class="form-control double" type="text" data-validate="required" />
                    </div>
                </div>
                <div class="modal-footer justify-content-between border-0">
                    <button type="button" class="btn btn-light font-weight-bolder" data-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-primary font-weight-bolder"><?= lang('Layout.btn_save_caption'); ?></button>
                </div>
            </form>
            <!--end::Form-->
        </div>
    </div>
</div>
