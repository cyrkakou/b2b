<style>
    .table.table-sm thead th{
        padding: 0.3rem;
    }
</style>
<div class="card card-custom gutter-b bordered">
    <div class="card-header">
        <div class="card-title">
                <span class="card-icon">
                    <i class="far fa-database"></i>
                </span>
            <h3 class="card-label">
                Liste des promotions - (<?= count(@$dataset) ?>)
            </h3>
        </div>
        <div class="card-toolbar">
            <?php if(user_can('create')):?>
                <a href="javascript:;" data-toggle="modal" data-target="#modal_promotion_create"
                class="btn btn-light-primary font-weight-bolder">
                    <i class="far fa-plus"></i>
                    Ajouter
                </a>
                <?php endif;?>
        </div>
    </div>
    <div class="card-body p-0">
        <!--begin: Datatable -->
        <div class="table-responsive">
            <table id="DT_promotions" class="table table-head-custom table-head-bg table-vertical-center rounded-0 datagrid" >
                <thead>
                <tr>
                    <th class="no-sort" style="width: 1%;">
                        <label class="checkbox checkbox-outline checkbox-outline-2x checkbox-danger checkbox-single">
                            <input type="checkbox" value="" class="group-checkable">
                            <span></span>
                        </label>
                    </th>
                    <th style="width: 20px"> Id</th>
                    <th nowrap=""> Promotion</th>
                    <th nowrap=""> Ville</th>
                    <th class="text-center"> Superficie</th>
                    <th class="text-center"> logements</th>
                    <th> Standing</th>
                    <th> Prix</th>
                    <th class="text-center"> Avancement</th>
                    <th> date</th>
                    <th style="width: 1%;" class="no-sort text-center"> Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php if (count(@$dataset) > 0): ?>
                    <?php foreach ($dataset as $rows): ?>
                        <tr>
                            <td>
                                <label class="checkbox checkbox-outline checkbox-outline-2x checkbox-primary checkbox-single">
                                    <input name="selected[]" value="<?= $rows->promotionID ?>" type="checkbox" value="" class="checkable">
                                    <span></span>
                                </label>
                            </td>
                            <td><?= @$rows->promotionID ?></td>
                            <td>
                                <div class="d-flex flex-column font-weight-bold">
                                    <a href="javascript:;" class="text-dark text-hover-primary mb-1 font-size-lg"><?= @$rows->libelle?></a>
                                    <span class="text-muted"><?= @$rows->raison_sociale?></span>
                                </div>
                            </td>
                            <td><?= @$rows->villeLibelle?></td>
                            <td class="text-center"><?= thousand(@$rows->superficie)?></td>
                            <td class="text-center"><?= thousand(@$rows->nombre_logement)?></td>
                            <td><?= @$rows->standing?></td>
                            <td class="text-right"><?= thousand(@$rows->prix)?></td>
                            <td nowrap="" class="text-center">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: <?= intval(@$rows->avancement)?>%;">
                                        <?= intval(@$rows->avancement)?>%
                                    </div>
                                </div>
                            </td>
                            <td nowrap=""><?= mysql_to_date(@$rows->date_deb)?></td>
                            <td nowrap>
                                <?php if(user_can('update')):?>                                
                                    <a href="javascript:;" data-toggle="modal" data-target="#modal_promotion_update"
                                    data-promotionID="<?=@$rows->promotionID?>"
                                    class="btn btn-icon btn-sm btn-light-warning"><i class="far fa-pencil"></i>
                                    </a>
                                <?php endif?>
                                <a href="javascript:;" data-toggle="modal" data-target="#modal_promotion_gps"
                                   data-promotionID="<?=@$rows->promotionID?>"
                                   class="btn btn-icon btn-sm btn-light-info">
                                    <i class="far fa-map-marker-plus"></i>
                                </a>
                                <?php if(user_can('delete')):?>                                
                                    <a href="javascript:;" data-toggle="modal" data-target="#modal_promotion_delete"
                                    data-promotionID="<?=@$rows->promotionID?>"
                                    class="btn btn-icon btn-sm btn-light-danger">
                                        <i class="far fa-trash"></i>
                                    </a>
                                <?php endif?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <!--end: Datatable -->
    </div>
</div>
