<div id="modal_promotion_gps" class="modal right fade" data-backdrop="static" tabindex="-1" permission="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <!--begin::Form-->
            <form action="<?=base_url('ressources/promotions/gps'); ?>" class="validate" role="form"
                  enctype="multipart/form-data" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bolder">Délimitation de la superficie</h5>
                    <button type="button" class="btn btn-xs btn-icon btn-light btn-hover-primary" data-dismiss="modal" aria-label="Close">
                        <i class="ki ki-close icon-xs text-muted"></i>
                    </button>
                </div>
                <div class="modal-body min-w-350px p-0">
                    <table id="makers_list" class="table table-sm table-bordered table-vertical-center">
                        <thead class="bg-light">
                        <tr>
                            <th scope="col" class="mx-2">Id</th>
                            <th scope="col" class="mx-2">Latitude</th>
                            <th scope="col" class="mx-2">Longitude</th>
                            <th scope="col" class="mx-2">altitude</th>
                            <th style="width:20px">
                                <button id="btn_add_marker" type="button" class="btn btn-xs btn-icon btn-primary" data-toggle="modal"
                                        data-target="#modal_addmarker"
                                        data-promotionID="">
                                    <i class="far fa-map-marker-plus"></i>
                                </button>
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer justify-content-between border-0">
                    <button type="button" class="btn btn-light font-weight-bolder" data-dismiss="modal">Fermer</button>
                </div>
            </form>
            <!--end::Form-->
        </div>
    </div>
</div>
