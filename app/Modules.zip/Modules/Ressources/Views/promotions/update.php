<div id="modal_promotion_update" class="modal right fade" data-backdrop="static" tabindex="-1"  aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <!--begin::Form-->
            <form action="<?=base_url('ressources/promotions/update'); ?>" class="validate" role="form"
                  enctype="multipart/form-data" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bolder"><?= lang('Layout.form_update_caption'); ?></h5>
                    <button type="button" class="btn btn-xs btn-icon btn-light btn-hover-primary" data-dismiss="modal" aria-label="Close">
                        <i class="ki ki-close icon-xs text-muted"></i>
                    </button>
                </div>
                <div class="modal-body min-w-350px">
                    <input name="promotionID" type="hidden" />
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Promoteur<span
                                class="text-danger ml-2">*</span></label>
                        <?php dropDown('SELECT promoteurID,raison_sociale FROM promoteurs', [
                            'name' => 'promoteurID',
                            'class' => 'form-control select2-simple',
                            'attr' => 'data-placeholder="Choisir un promoteur" data-validate="required"',
                        ]); ?>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Ville<span
                                class="text-danger ml-2">*</span></label>
                        <?php dropDown('SELECT villeID,villeLibelle FROM settings_villes WHERE paysCode = "CI" ORDER BY villeLibelle', [
                            'name' => 'villeID',
                            'class' => 'form-control select2-simple',
                            'attr' => 'data-placeholder="Choisir une ville" data-validate="required"',
                        ]); ?>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Libellé<span
                                class="text-danger ml-2">*</span></label>
                        <input name="libelle" class="form-control" type="text" data-validate="required"/>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Date début<span
                                class="text-danger ml-2">*</span></label>
                        <input name="date_deb" class="form-control mask-date" type="text" />
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Superficie (m²)<span
                                class="text-danger ml-2">*</span></label>
                        <input name="superficie" class="form-control double" type="text" />
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Nombre de logement<span
                                class="text-danger ml-2">*</span></label>
                        <input name="nombre_logement" class="form-control integer" type="text" />
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Standing<span
                                class="text-danger ml-2">*</span></label>
                        <?php dropDown('SELECT standingLibelle,standingLibelle FROM settings_standing', [
                            'name' => 'standing',
                            'class' => 'form-control select2-simple',
                            'attr' => 'data-placeholder="Choisir un standing"',
                        ]); ?>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Avancement<span
                                class="text-danger ml-2">*</span></label>
                        <input name="avancement" class="form-control double" type="text"/>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Prix<span
                                class="text-danger ml-2">*</span></label>
                        <input name="prix" class="form-control double" type="text"/>
                    </div>
                </div>
                <div class="modal-footer justify-content-between border-0">
                    <button type="button" class="btn btn-light font-weight-bolder" data-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-primary font-weight-bolder"><?= lang('Layout.btn_save_caption'); ?></button>
                </div>
            </form>
            <!--end::Form-->
        </div>
    </div>
</div>
