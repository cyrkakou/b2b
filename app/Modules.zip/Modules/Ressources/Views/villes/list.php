<div class="card card-custom gutter-b bordered">
    <div class="card-header">
        <div class="card-title">
                <span class="card-icon">
                    <i class="far fa-database"></i>
                </span>
            <h3 class="card-label">
                Liste des villes - (<?= count(@$dataset) ?>)
            </h3>
        </div>
        <div class="card-toolbar">
            <a href="javascript:;" data-toggle="modal" data-target="#modal_ville_create"
               class="btn btn-light-primary font-weight-bolder">
                <i class="far fa-plus"></i>
                Ajouter
            </a>
        </div>
    </div>
    <div class="card-body p-0">
        <!--begin: Datatable -->
        <table id="DT_Villes" class="table table-sm table-head-custom table-head-bg table-vertical-center rounded-0 datagrid" >
            <thead>
            <tr>
                <th class="no-sort" style="width: 1%;">
                    <label class="checkbox checkbox-outline checkbox-outline-2x checkbox-danger checkbox-single">
                        <input type="checkbox" value="" class="group-checkable">
                        <span></span>
                    </label>
                </th>
                <th style="width: 20px"> Id</th>
                <th style="width:100%"> Libell&eacute;</th>
                <th style="width: 1%;" class="no-sort text-center"> Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php if (count(@$dataset) > 0): ?>
                <?php foreach ($dataset as $rows): ?>
                    <tr>
                        <td>
                            <label class="checkbox checkbox-outline checkbox-outline-2x checkbox-primary checkbox-single">
                                <input name="selected[]" value="<?= $rows->villeID ?>" type="checkbox" value="" class="checkable">
                                <span></span>
                            </label>
                        </td>
                        <td><?= @$rows->villeID ?></td>
                        <td><?= @$rows->villeLibelle?></td>
                        <td nowrap>
                            <a href="javascript:;" data-toggle="modal" data-target="#modal_ville_update"
                               data-villeID="<?=@$rows->villeID?>"
                               class="btn btn-icon btn-sm btn-light-warning"><i class="far fa-pencil"></i>
                            </a>
                            <a href="javascript:;" data-toggle="modal" data-target="#modal_ville_delete"
                               data-villeID="<?=@$rows->villeID?>"
                               class="btn btn-icon btn-sm btn-light-danger">
                                <i class="far fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
        <!--end: Datatable -->
    </div>
</div>
