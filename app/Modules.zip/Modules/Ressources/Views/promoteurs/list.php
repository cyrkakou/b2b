<div class="card card-custom gutter-b bordered">
    <div class="card-header">
        <div class="card-title">
                <span class="card-icon">
                    <i class="far fa-database"></i>
                </span>
            <h3 class="card-label">
                Liste des promoteurs - (<?= count(@$dataset) ?>)
            </h3>
        </div>
        <div class="card-toolbar">
            <?php if(user_can('create')):?>
                <a href="javascript:;" data-toggle="modal" data-target="#modal_promoteur_create"
                class="btn btn-light-primary font-weight-bolder">
                    <i class="far fa-plus"></i>
                    Ajouter
                </a>
            <?php endif;?>
        </div>
    </div>
    <div class="card-body p-0">
        <!--begin: Datatable -->
        <table id="DT_Promoteurs" class="table table-sm table-head-custom table-head-bg table-vertical-center rounded-0 datagrid" >
            <thead>
            <tr>
                <th class="no-sort" style="width: 1%;">
                    <label class="checkbox checkbox-outline checkbox-outline-2x checkbox-danger checkbox-single">
                        <input type="checkbox" value="" class="group-checkable">
                        <span></span>
                    </label>
                </th>
                <th style="width: 20px"> Id</th>
                <th style="width:100%"> Raison sociale</th>
                <th> Email</th>
                <th> Contact</th>
                <th style="width: 1%;" class="no-sort text-center"> Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php if (count(@$dataset) > 0): ?>
                <?php foreach ($dataset as $rows): ?>
                    <tr>
                        <td>
                            <label class="checkbox checkbox-outline checkbox-outline-2x checkbox-primary checkbox-single">
                                <input name="selected[]" value="<?= $rows->promoteurID ?>" type="checkbox" value="" class="checkable">
                                <span></span>
                            </label>
                        </td>
                        <td><?= @$rows->promoteurID ?></td>
                        <td><?= @$rows->raison_sociale?></td>
                        <td><?= @$rows->email?></td>
                        <td nowrap=""><?= @$rows->telephone_mobile?></td>
                        <td nowrap>
                        <?php if(user_can('update')):?>
                            <a href="javascript:;" data-toggle="modal" data-target="#modal_promoteur_update"
                               data-promoteurID="<?=@$rows->promoteurID?>"
                               class="btn btn-icon btn-sm btn-light-warning"><i class="far fa-pencil"></i>
                            </a>
                            <?php endif;?>                            
                            <?php if(user_can('delete')):?>
                            <a href="javascript:;" data-toggle="modal" data-target="#modal_promoteur_delete"
                               data-promoteurID="<?=@$rows->promoteurID?>"
                               class="btn btn-icon btn-sm btn-light-danger">
                                <i class="far fa-trash"></i>
                            </a>
                            <?php endif;?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
        <!--end: Datatable -->
    </div>
</div>
