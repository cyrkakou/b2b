<div id="modal_promoteur_update" class="modal right fade" data-backdrop="static" tabindex="-1" permission="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <!--begin::Form-->
            <form action="<?=base_url('ressources/promoteurs/update'); ?>" class="validate" role="form"
                  enctype="multipart/form-data" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title font-weight-bolder"><?= lang('Layout.form_add_caption'); ?></h5>
                    <button type="button" class="btn btn-xs btn-icon btn-light btn-hover-primary" data-dismiss="modal" aria-label="Close">
                        <i class="ki ki-close icon-xs text-muted"></i>
                    </button>
                </div>
                <div class="modal-body min-w-350px">
                    <input name="promoteurID" type="text">
                    <section>
                        <div class="form-group">
                            <label class="control-label font-weight-bold">Raison sociale<span
                                    class="text-danger ml-2">*</span></label>
                            <input name="raison_sociale" class="form-control" type="text" data-validate="required"/>
                        </div>
                    </section>
                    <section>
                        <div class="separator separator-dashed my-5"></div>
                        <h5 class="text-dark font-weight-bold mb-6">Contact</h5>
                        <div class="form-group">
                            <label class="control-label font-weight-bold">Adresse électronique<span
                                    class="text-danger ml-2">*</span></label>
                            <div class="input-icon">
                                <input name="email" id="email" type="email" class="form-control"
                                       data-validate="required,email">
                                <a href="javascript:;" data-action="email" data-field="email"
                                   title="générer une adresse fictive"
                                   class="">
                                    <span><i class="far fa-envelope"></i></span>
                                </a>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label font-weight-bold">Téléphone Fixe<span
                                    class="text-danger ml-2">*</span>
                                (+<?= @$config->country_phone_code ?>)
                            </label>
                            <div class="input-icon">
                                <input name="telephone_fixe"
                                       class="form-control mask-phone-<?= strtolower(@$config->country_code) ?>"
                                       type="text"/>
                                <span>
                                        <i class="far fa-phone-alt"></i>
                                    </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label font-weight-bold">Téléphone Mobile<span
                                    class="text-danger ml-2">*</span>
                                (+<?= @$config->country_phone_code ?>)
                            </label>
                            <div class="input-icon">
                                <input name="telephone_mobile"
                                       class="form-control mask-phone-<?= strtolower(@$config->country_code) ?>"
                                       data-validate="required"
                                       type="text"/>
                                <span>
                                        <i class="far fa-mobile-alt"></i>
                                    </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label font-weight-bold">Site web</label>
                            <input name="site_web"
                                   class="form-control url"
                                   type="url"/>
                        </div>
                    </section>
                </div>
                <div class="modal-footer justify-content-between border-0">
                    <button type="button" class="btn btn-light font-weight-bolder" data-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-primary font-weight-bolder"><?= lang('Layout.btn_save_caption'); ?></button>
                </div>
            </form>
            <!--end::Form-->
        </div>
    </div>
</div>
