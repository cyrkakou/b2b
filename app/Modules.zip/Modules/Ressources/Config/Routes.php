<?php
$routes->group('ressources', ['namespace' => 'App\Modules\Ressources\Controllers'], function ($routes) {
    $routes->group('promoteurs', function ($routes) {
        $routes->add('/', 'Promoteurs::index');
        $routes->add('(:any)', 'Promoteurs::$1');
    });
    $routes->group('promotions', function ($routes) {
        $routes->add('/', 'Promotions::index');
        $routes->add('(:any)', 'Promotions::$1');
    });
    $routes->group('villes', function ($routes) {
        $routes->add('/', 'Villes::index');
        $routes->add('(:any)', 'Villes::$1');
    });
});
?>
