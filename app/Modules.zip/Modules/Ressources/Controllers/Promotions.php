<?php
namespace App\Modules\Ressources\Controllers;
use App\Controllers\IbemsController;
use App\Modules\Api\Models\PromotionModel;

class Promotions extends IbemsController {
    protected $promotionModel;
    public function __construct(){
        parent::__construct();
        is_protected(['root','admin','client']);
        $this->promotionModel = new promotionModel();

        self::set_crumb([
            ['text'=>'promotions','url'=>base_url('ressources/promotions')]
        ]);
        self::set_data('page_title','Gestion des promotions');
        self::set_data('breadcrumb',self::breadcrumb());
        //
        self::add_data('content', view('App\Modules\Ressources\Views\promotions\create', self::get_data()));
        self::add_data('content', view('App\Modules\Ressources\Views\promotions\update', self::get_data()));
        self::add_data('content', view('App\Modules\Ressources\Views\promotions\delete', []));
        self::add_data('content', view('App\Modules\Ressources\Views\promotions\gps', []));
        self::add_data('content', view('App\Modules\Ressources\Views\promotions\add_marker', []));
        self::add_data('content', view('App\Modules\Ressources\Views\promotions\update_marker', []));
        self::add_data('content', view('App\Modules\Ressources\Views\promotions\delete_marker', []));
    }
    public function index()
    {
        self::add_crumb(['text'=>'Lister']);
        self::set_data('dataset',$this->promotionModel::lister());
        self::add_data('content',view('App\Modules\Ressources\Views\promotions\list',self::get_data()));
        return view('backend/layout',self::get_data());
    }
    public function do_find($promotionID)
    {
        if($response = $this->promotionModel::trouver(intval($promotionID))){
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function create(){
        if ($this->request->getMethod() == "post") {
            $response = '';
            if($this->promotionModel::ajouter([]))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_create_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_create_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function update()
    {
        if (isPostBack()) {
            $response = [];
            if($this->promotionModel::modifier($this->request->getPost('promotionID')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_update_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_update_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function delete(){
        if ($this->request->getMethod() == "post") {
            $response = [];
            if($this->promotionModel::supprimer($this->request->getPost('primary_key')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_delete_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_delete_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function get_markers($promotionID)
    {
        if($response = $this->promotionModel::get_markers(intval($promotionID))){
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function add_marker(){
        if ($this->request->getMethod() == "post") {
            $response = [];
            if($this->promotionModel::add_marker())
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_delete_success'),
                    'gpsID'=>db()->insertID()
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_delete_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function update_marker(){
        if ($this->request->getMethod() == "post") {
            $response = [];
            if($this->promotionModel::update_marker(
                $this->request->getPost('gpsID'),
                $this->request->getPost('field'),
                $this->request->getPost('valeur')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_delete_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_delete_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function delete_marker(){
        if ($this->request->getMethod() == "post") {
            $response = [];
            if($this->promotionModel::delete_marker($this->request->getPost('gpsID')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_delete_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_delete_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }

}
