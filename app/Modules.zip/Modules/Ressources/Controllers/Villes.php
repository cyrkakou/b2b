<?php
namespace App\Modules\Ressources\Controllers;
use App\Controllers\IbemsController;
use App\Modules\Api\Models\VilleModel;

class villes extends IbemsController {
    protected $villeModel;
    public function __construct(){
        parent::__construct();
        is_protected(['root','admin','backoffice']);
        $this->villeModel = new villeModel();

        self::set_crumb([
            ['text'=>'villes','url'=>base_url('ressources/villes')]
        ]);
        self::set_data('page_title','Gestion des villes');
        self::set_data('breadcrumb',self::breadcrumb());
        //
        self::add_data('content', view('App\Modules\Ressources\Views\villes\create', self::get_data()));
        self::add_data('content', view('App\Modules\Ressources\Views\villes\update', self::get_data()));
        self::add_data('content', view('App\Modules\Ressources\Views\villes\delete', []));
    }
    public function index()
    {
        self::add_crumb(['text'=>'Lister']);
        self::set_data('dataset',$this->villeModel::lister());
        self::add_data('content',view('App\Modules\Ressources\Views\villes\list',self::get_data()));
        return view('backend/layout',self::get_data());
    }
    public function do_find($villeID)
    {
        if($response = $this->villeModel->find(intval($villeID))){
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function create(){
        if ($this->request->getMethod() == "post") {
            $response = '';
            if($this->villeModel::ajouter([]))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_create_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_create_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function update()
    {
        if (isPostBack()) {
            $response = [];
            if($this->villeModel::modifier($this->request->getPost('villeID')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_update_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_update_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function delete(){
        if ($this->request->getMethod() == "post") {
            $response = [];
            if($this->villeModel::supprimer($this->request->getPost('primary_key')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_delete_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_delete_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
}
