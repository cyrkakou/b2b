<?php
namespace App\Modules\Settings\Controllers;

use App\Controllers\IbemsController;
use App\Modules\Settings\Models\MedecinModel;

class Medecin extends IbemsController
{
    protected $MedecinModel;

    public function __construct()
    {
        parent::__construct();
        is_protected(['root','admin','backoffice']);

        self::set_crumb([
            ['text'=>'Medecins','url'=>base_url('settings/medecin')]
        ]);
        self::set_data('page_title','Gestion des médecins');
        self::set_data('breadcrumb',self::breadcrumb());
        //modal
        self::add_data('content', view('App\Modules\Settings\Views\medecin\create', []));
        self::add_data('content', view('App\Modules\Settings\Views\medecin\update', []));
        self::add_data('content', view('App\Modules\Settings\Views\medecin\delete', []));
    }

    public function index(){

        $medecinModel = new MedecinModel();
        $medecins = $medecinModel->getAll();
        self::set_data('datagrid',$medecins);
        self::add_data('content',view('App\Modules\Settings\Views\medecin\list',self::get_data()));
        return view('backend/layout',self::get_data());
    }

    public function do_find($medecin_id)
    {
        if($response = $this->MedecinModel->find(intval($medecin_id))){
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function do_create()
    {
        if (isPostBack()) {
            $response = [];
            if($this->MedecinModel::ajouter())
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_create_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_create_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function do_update()
    {
        if (isPostBack()) {
            $response = [];
            if($this->MedecinModel::modifier($this->request->getPost('id')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_update_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_update_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
    public function do_delete(){

        if (isPostBack()) {
            $response = [];
            if($this->MedecinModel::supprimer($this->request->getPost('primary_key')))
            {
                $response = [
                    'statut' => 'success',
                    'icon' => 'fad fa-exclamation',
                    'title' => 'Bravo !!!',
                    'message' => lang('Layout.msg_delete_success'),
                ];
            } else {
                $response = [
                    'statut' => 'error',
                    'icon' => 'fad fa-times-circle',
                    'title' => 'Ooops !!!',
                    'message' => lang('Layout.msg_delete_failed')
                ];
            }
            header('Content-Type: application/json');
            echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit(0);
        }
    }
}
?>