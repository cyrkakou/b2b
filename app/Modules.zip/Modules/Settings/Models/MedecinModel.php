<?php

namespace App\Modules\Settings\Models;

use App\Controllers\IbemsModel;

class MedecinModel extends IbemsModel
{
    protected $db;
    protected $DBGroup              = 'default';
    protected $table                = 'medecin';
    protected $primaryKey           = 'id';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;

    protected $allowedFields = ['code', 'genre', 'nom', 'prenoms', 'specialite', 'adresse', 'zip', 'ville', 'telephone', 'email', 'created_by', 'status'];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [
        'code'         => 'required',
        'nom'          => 'required',
        'prenoms'      => 'required',
        'email'        => 'required|valid_email|is_unique[medecin.email]',
    ];
    protected $validationMessages   = [
        'email'        => [
            'is_unique' => 'Sorry. That email has already been taken. Please choose another.',
        ],
    ];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];

    public function __construct()
    {
        parent::__construct();
        $this->db = \Config\Database::connect();
    }

    public static function ajouter(array $args = []):bool{
        $data = self::sanitize_for('medecin',$args);
        return db('medecin')
            ->insert($data);
    }
    public static function modifier($primary_keys = null,array $data = []): bool
    {
        $data = self::sanitize_for(self::table,$data);
        return db(self::table)
            ->where('id',intval($primary_keys))
            ->update($data);
    }
    public static function supprimer(mixed $primary_keys):bool{
        if(is_array($primary_keys)){
            return db('medecin')
                ->whereIn('id',$primary_keys)
                ->delete();
        }else{
            return db('medecin')
                ->where('id',intval($primary_keys))
                ->delete();
        }
    }

    public function getAll(){
        $rs = $this->db
            ->table('medecin')
            ->select('medecin.*, medecin_status.class,medecin_status.label')
            ->join('medecin_status','medecin_status.code = medecin.status','left')
            ->orderBy('id','DESC')
            ->get()
            ->getResult();
        return $rs;
    }

    public function find($medecin_id=0){
        $rs = $this->db
            ->table('medecin')
            ->select('medecin.*, medecin_status.class,medecin_status.label')
            ->join('medecin_status','medecin_status.code = medecin.status','left')
            ->where('id',$medecin_id)
            ->orderBy('id','DESC')
            ->get()
            ->getResult();
        return $rs;
    }
}