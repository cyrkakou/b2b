<!-- begin:Modal-->
<div id="form_medecin_create" class="modal right fade" data-backdrop="static" tabindex="-1" role="dialog"
     aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <!--begin::Form-->
            <form action="<?=base_url('settings/medecin/do_create'); ?>" class="validate" role="form"
                  enctype="multipart/form-data" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title mr-2"><?= lang('Layout.form_add_caption'); ?></h5>
                    <a href="javascript:;" class="btn btn-xs btn-icon btn-light btn-hover-primary" data-dismiss="modal">
                        <i class="ki ki-close icon-xs text-muted"></i>
                    </a>
                </div>
                <div class="modal-body pb-0 min-w-350px">
                    <div class="form-group">
                        <label class="control-label kt-font-bold">Code:<span
                                    class="text-danger ml-2">*</span></label>
                        <input name="code" class="form-control alpha-code text-lowercase" type="text"
                               data-validate="required"/>
                        <span class="form-text text-muted">Code d'identification</span>
                    </div>
                    <div class="form-group">
                        <label class="col-3 col-form-label">Genre:</label>
                        <input name="gender" type="checkbox"
                               data-switch="true"
                               data-on-text="H"
                               data-off-text="F"
                               data-on-color="primary" data-off-color="success" value="1" checked>
                        <span class="form-text text-muted">Genre du médecin</span>
                    </div>
                    <div class="form-group">
                        <label class="control-label kt-font-bold">Nom:<span
                                    class="text-danger ml-2">*</span></label>
                        <input name="nom" class="form-control" type="text"
                               data-validate="required"/>
                        <span class="form-text text-muted">Nom du médecin</span>
                    </div>
                    <div class="form-group">
                        <label class="control-label kt-font-bold">Prénoms:<span
                                    class="text-danger ml-2">*</span></label>
                        <input name="prenoms" class="form-control" type="text"
                               data-validate="required"/>
                        <span class="form-text text-muted">Prénoms du médecin</span>
                    </div>
                    <div class="form-group">
                        <label class="control-label kt-font-bold">Spécialité:<span
                                    class="text-danger ml-2">*</span></label>
                        <input name="specialite" class="form-control" type="text"
                               data-validate="required"/>
                        <span class="form-text text-muted">Spécialité du médecin</span>
                    </div>
                    <div class="form-group">
                        <label class="control-label">N° téléphone:<span
                                    class="text-danger ml-2">*</span>
                        </label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">+225</span>
                            </div>
                            <input name="phone"
                                   class="form-control mask-phone-ci"
                                   data-validate="required"
                                   type="text"/>
                        </div>
                        <span class="form-text text-muted">Numéro téléphone du médecin</span>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Adresse:<span
                                    class="text-danger ml-2">*</span>:</label>
                        <div class="input-icon">
                            <input  name="adress"
                                    class="form-control alphanum" type="text"
                                    data-validate="required"/>
                            <span>
                                <i class="far fa-map-marker"></i>
                            </span>
                        </div>
                        <span class="form-text text-muted">Adresse du médecin</span>
                    </div>
                    <div class="form-group">
                        <label class="control-label font-weight-bold">Email:<span class="text-danger ml-2">(*)</span></label>
                        <div class="">
                            <div class="input-icon">
                                <input name="user_email" type="text" class="form-control" data-validate="required">
                                <span><i class="fa fa-envelope"></i></span>
                            </div>
                            <span class="form-text text-muted">Adresse email du médecin</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-secondary font-weight-bold" data-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-light-primary font-weight-bold"><?= lang('Layout.btn_save_caption'); ?></button>
                </div>
            </form>
            <!--end::Form-->
        </div>
    </div>
</div>
<!-- end:Modal-->
