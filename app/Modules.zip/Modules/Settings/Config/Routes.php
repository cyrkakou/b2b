<?php
$routes->group('settings', ['namespace' => 'App\Modules\Settings\Controllers'], function ($routes) {
    $routes->group('control_panel', function ($routes) {
        $routes->add('/', 'ControlPanel::index');
        $routes->add('(:any)', 'ControlPanel::$1');
    });
    $routes->group('medecin', function ($routes) {
        $routes->add('/', 'Medecin::index');
        $routes->add('(:any)', 'Medecin::$1');
    });
    $routes->group('pharmacies', function ($routes) {
        $routes->add('/', 'Pharmacies::index');
        $routes->add('(:any)', 'Pharmacies::$1');
    });
});
