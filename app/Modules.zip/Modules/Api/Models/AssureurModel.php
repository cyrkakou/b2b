<?php

namespace App\Modules\Api\Models;

use App\Controllers\IbemsModel;

class AssureurModel extends IbemsModel
{
    protected $DBGroup              = 'default';
    protected $table                = 'assureurs';
    protected $primaryKey           = 'assureurID';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;
    protected $allowedFields        = [
        "name",
        "email",
        "mobile"
    ];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    public function __construct(){
        parent::__construct();
    }
    public static function ajouter(array $args = []):bool{
        $raison_sociale = request()->getVar("raison_sociale");
        $email = request()->getVar("email",FILTER_SANITIZE_EMAIL);
        $mobile = request()->getVar("telephone_mobile");
        $password = request()->getVar("user_password");
        $added_by = get_user_info('user_id');
        db()->transStart();
        $data = self::sanitize_for('assureurs',$args);
        $data['added'] = time();
        $data['added_by'] = $added_by;
        //assureur
        db('assureurs')->insert($data);
        $assureurID = db()->insertID();
        //user
        $data = self::sanitize_for('users',$args);

        $data['role_id'] = get_role('assureur');
        $data['user_nicename'] = $raison_sociale;
        $data['user_email'] = $email;
        $data['user_phone'] = str_replace(['-',' '],['',''],$mobile);
        $data['user_registered'] = time();
        $data['identifier'] = identifier();
        $data['hash'] = crypt($password,salt(32));
        $data['added_by'] = $added_by;
        db('users')->insert($data);
        $userID = db()->insertID();
        //
        db('assureurs_users')->insert([
            'assureurID'=>$assureurID,
            'userID'=>$userID
        ]);
        db()->transComplete();
        return db()->transStatus() !== false;

    }
    public static function modifier($primary_keys = null,array $data = []): bool
    {
        $data = self::sanitize_for('users_roles',$data);
        return db('users_roles')
            ->where('role_id',intval($primary_keys))
            ->update($data);;
    }
    public static function supprimer(int $primary_keys):bool{
        if($rs = self::trouver($primary_keys)){
            db()->transStart();
            if($rs1 = db('assureurs_users')
                ->select('userID')
                ->where('assureurID',intval($primary_keys))
                ->get()
                ->getRow()){
                db('users')
                    ->where('user_id',intval($rs1->userID))
                    ->delete();
            }
            db('assureurs')
                ->where('assureurID',intval($primary_keys))
                ->delete();
            db()->transComplete();
            return db()->transStatus() !== false;
        }
        return false;
    }
    public static function lister()
    {
        if($rs =  db('assureurs')
            ->get()){
            return $rs->getResult();
        }
        return [];
    }
    public static function trouver(int $primary_key)
    {
        if($rs =  db('assureurs')
            ->where('assureurs.assureurID',intval($primary_key))
            ->get()
        ){
            return $rs->getRow();
        }
        return false;
    }
}
