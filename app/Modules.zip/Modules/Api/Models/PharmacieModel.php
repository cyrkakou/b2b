<?php

namespace App\Modules\Api\Models;

use App\Controllers\IbemsModel;

class PharmacieModel extends IbemsModel
{
    protected $DBGroup              = 'default';
    protected $table                = 'pharmacies';
    protected $primaryKey           = 'pharmacieID';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;
    protected $allowedFields        = [
        "name",
        "email",
        "mobile"
    ];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    public function __construct(){
        parent::__construct();
    }
    public static function ajouter(array $args = []):bool{
        $raison_sociale = request()->getVar("pharmacie_raison_sociale");
        $login = request()->getVar("user_login");
        $email = request()->getVar("pharmacie_email",FILTER_SANITIZE_EMAIL);
        $mobile = request()->getVar("pharmacie_mobile");
        $password = request()->getVar("user_password");
        $added_by = get_user_info('user_id');
        db()->transStart();
        $data = self::sanitize_for('pharmacies',$args);
        db('pharmacies')->insert($data);
        $pharmacieID = db()->insertID();
        //user
        $data = self::sanitize_for('users',$args);

        $data['role_id'] = get_role('pharmacie');
        $data['user_login'] = $login;
        $data['user_nicename'] = $raison_sociale;
        $data['user_email'] = $email;
        $data['user_phone'] = str_replace(['-',' '],['',''],$mobile);
        $data['user_registered'] = time();
        $data['identifier'] = identifier();
        $data['hash'] = crypt($password,salt(32));
        $data['added_by'] = $added_by;
        db('users')->insert($data);
        $userID = db()->insertID();
        //
        db('pharmacies_user')->insert([
            'pharmacie_id'=>$pharmacieID,
            'user_id'=>$userID
        ]);
        db()->transComplete();
        return db()->transStatus() !== false;
    }
    public static function modifier($primary_keys = null,array $data = []): bool
    {
        $data = self::sanitize_for('users_roles',$data);
        return db('users_roles')
            ->where('role_id',intval($primary_keys))
            ->update($data);;
    }
    public static function supprimer(mixed $primary_keys):bool{
        if(is_array($primary_keys)){
            return db('users_roles')
                ->whereIn('role_id',$primary_keys)
                ->delete();;
        }else{
            return db('users_roles')
                ->where('role_id',intval($primary_keys))
                ->delete();;
        }
    }
    public static function lister()
    {
        if($rs =  db('pharmacies')
            ->get()){
            return $rs->getResult();
        }
        return [];
    }
}
