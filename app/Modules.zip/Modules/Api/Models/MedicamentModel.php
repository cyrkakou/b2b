<?php

namespace App\Modules\Api\Models;

use App\Controllers\IbemsModel;

class MedicamentModel extends IbemsModel
{
    protected $DBGroup              = 'default';
    protected $table                = 'medicaments';
    protected $primaryKey           = 'medicamentID';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;
    protected $allowedFields        = [
        "name",
        "email",
        "mobile"
    ];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    public function __construct(){
        parent::__construct();
    }
    public static function ajouter(array $args = []):bool{
        db()->transStart();
        $data = self::sanitize_for('medicaments',$args);
        $data['added'] = time();
        $data['added_by'] = get_user_info('user_id');
        db('medicaments')->insert($data);
        db()->transComplete();
        return db()->transStatus() !== false;

    }
    public static function modifier(int $primary_keys,array $data = []): bool
    {
        $data = self::sanitize_for('medicaments',$data);
        return db('medicaments')
            ->where('medicamentID',intval($primary_keys))
            ->update($data);;
    }
    public static function supprimer(int $primary_keys):bool{
        if($rs = self::trouver($primary_keys)){
            db()->transStart();
            db('medicaments')
                ->where('medicamentID',intval($primary_keys))
                ->delete();
            db()->transComplete();
            return db()->transStatus() !== false;
        }
        return false;
    }
    public static function trouver(int $primary_key)
    {
        if($rs =  db('medicaments')
            ->where('medicamentID',intval($primary_key))
            ->get()
        ){
            return $rs->getRow();
        }
        return false;
    }
    public static function lister()
    {
        if($rs =  db('medicaments')
            ->get()){
            return $rs->getResult();
        }
        return [];
    }

}
