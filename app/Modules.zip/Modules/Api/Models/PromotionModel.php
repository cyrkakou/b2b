<?php

namespace App\Modules\Api\Models;

use App\Controllers\IbemsModel;

class PromotionModel extends IbemsModel
{
    protected $DBGroup              = 'default';
    protected $table                = 'promotions';
    protected $primaryKey           = 'promotionID';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;
    protected $allowedFields        = [];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    public function __construct(){
        parent::__construct();
    }
    public static function ajouter(array $args = []):bool{
        $data = self::sanitize_for('promotions',$args);
        if(isset($data['date_deb'])) $data['date_deb'] = date_to_mysql($data['date_deb']);
        return db('promotions')
            ->insert($data);;
    }
    public static function modifier($primary_keys = null,array $data = []): bool
    {        
        $data = self::sanitize_for('promotions',$data);
        if(isset($data['date_deb'])) $data['date_deb'] = date_to_mysql($data['date_deb']);
        return db('promotions')
            ->where('promotionID',intval($primary_keys))
            ->update($data);;
    }
    public static function supprimer(mixed $primary_keys):bool{
        if(is_array($primary_keys)){
            return db('promotions')
                ->whereIn('promotionID',$primary_keys)
                ->delete();;
        }else{
            return db('promotions')
                ->where('promotionID',intval($primary_keys))
                ->delete();;
        }
    }
    public static function lister(){
        return db('promotions')
            ->join('promoteurs','promoteurs.promoteurID = promotions.promoteurID','left')
            ->join('settings_villes','settings_villes.villeID = promotions.villeID','left')
            ->get()
            ->getResult();
    }
    public static function trouver(int $promotionID)
    {
        return db('promotions')
            ->join('promoteurs','promoteurs.promoteurID = promotions.promoteurID','left')
            ->join('settings_villes','settings_villes.villeID = promotions.villeID','left')
            ->where('promotionID',intval($promotionID))
            ->get()
            ->getRow();
    }
    public static function get_markers(int $promotionID){
        return db('promotions_gps')
            ->where('promotionID',intval($promotionID))
            ->get()
            ->getResult();
    }
    public static function add_marker(array $args = []):bool{
        $data = self::sanitize_for('promotions_gps',$args);
        return db('promotions_gps')->insert($data);
    }
    public static function update_marker($gpsid,$field,$value):bool{
        $args[$field] = doubleval($value);
        $data = self::sanitize_for('promotions_gps',$args);
        return db('promotions_gps')
            ->where('gpsID',intval($gpsid))
            ->update($data);;
    }
    public static function delete_marker(mixed $primary_keys):bool{
        if(is_array($primary_keys)){
            return db('promotions_gps')
                ->whereIn('gpsID',$primary_keys)
                ->delete();;
        }else{
            return db('promotions_gps')
                ->where('gpsID',intval($primary_keys))
                ->delete();;
        }
    }


}
