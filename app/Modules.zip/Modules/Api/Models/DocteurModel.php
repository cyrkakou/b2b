<?php

namespace App\Modules\Api\Models;

use App\Controllers\IbemsModel;

class DocteurModel extends IbemsModel
{
    protected $DBGroup              = 'default';
    protected $table                = 'docteurs';
    protected $primaryKey           = 'docteurID';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;
    protected $allowedFields        = [
        "name",
        "email",
        "mobile"
    ];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    public function __construct(){
        parent::__construct();
    }
    public static function ajouter(array $args = []):bool{
        $nom = request()->getVar("nom");
        $prenoms = request()->getVar("prenoms");
        $email = request()->getVar("email",FILTER_SANITIZE_EMAIL);
        $mobile = request()->getVar("mobile");
        $password = request()->getVar("user_password");
        $added_by = get_user_info('user_id');
        db()->transStart();
        $data = self::sanitize_for('docteurs',$args);
        $data['added'] = time();
        $data['added_by'] = $added_by;
        //docteur
        db('docteurs')->insert($data);
        $docteurID = db()->insertID();
        //personne
        $data = self::sanitize_for('personnes',$args);
        db('personnes')->insert($data);
        $personneID = db()->insertID();
        //user
        $data = self::sanitize_for('users',$args);

        $data['role_id'] = get_role('docteur');
        $data['user_nicename'] = $nom.' '.$prenoms;
        $data['user_email'] = $email;
        $data['user_phone'] = str_replace(['-',' '],['',''],$mobile);
        $data['user_registered'] = time();
        $data['identifier'] = identifier();
        $data['hash'] = crypt($password,salt(32));
        $data['added_by'] = $added_by;
        db('users')->insert($data);
        $userID = db()->insertID();
        //


        db('docteurs_personnes')->insert([
            'docteurID'=>$docteurID,
            'personneID'=>$personneID
        ]);
        db('docteurs_users')->insert([
            'docteurID'=>$docteurID,
            'userID'=>$userID
        ]);
        db()->transComplete();
        return db()->transStatus() !== false;

    }
    public static function modifier($primary_keys = null,array $data = []): bool
    {
        $data = self::sanitize_for('users_roles',$data);
        return db('users_roles')
            ->where('role_id',intval($primary_keys))
            ->update($data);;
    }
    public static function supprimer(int $primary_keys):bool{
        if($rs = self::trouver($primary_keys)){
            db()->transStart();
            db('docteurs')
                ->where('docteurID',intval($primary_keys))
                ->delete();
            db('personnes')
                ->where('personneID',intval($rs->personneID))
                ->delete();
            db('users')
                ->where('user_id',intval($rs->userID))
                ->delete();
            db()->transComplete();
            return db()->transStatus() !== false;
        }
        return false;
    }
    public static function lister()
    {
        if($rs =  db('docteurs')
            ->join('docteurs_personnes','docteurs_personnes.docteurID = docteurs.docteurID')
            ->join('personnes','personnes.personneID = docteurs_personnes.personneID')
            ->join('docteurs_users','docteurs_users.docteurID = docteurs.docteurID')
            ->join('users','users.user_id = docteurs_users.userID')
            ->get()){
            return $rs->getResult();
        }
        return [];
    }
    public static function trouver(int $primary_key)
    {
        if($rs =  db('docteurs')
            ->join('docteurs_personnes','docteurs_personnes.docteurID = docteurs.docteurID')
            ->join('personnes','personnes.personneID = docteurs_personnes.personneID')
            ->join('docteurs_users','docteurs_users.docteurID = docteurs.docteurID')
            ->join('users','users.user_id = docteurs_users.userID')
            ->where('docteurs.docteurID',intval($primary_key))
            ->get()
        ){
            return $rs->getRow();
        }
        return false;
    }
    public static function patient($docteurID){
        $patient = new PatientModel();
        $patient::$docteurID = $docteurID;
        return $patient;
    }
    public static function get_docteur_info()
    {
        $user_id =  $_SESSION['user']->user_id;
        if($rs = db('docteurs')
            ->join('docteurs_users','docteurs_users.docteurID = docteurs.docteurID','left')
            ->where('docteurs_users.userID',intval($user_id))
            ->get()){
            return $rs->getRow();
        }
        return new \stdClass();
    }
}
