<?php

namespace App\Modules\Api\Models;

use App\Controllers\IbemsModel;

class PromoteurModel extends IbemsModel
{
    protected $DBGroup              = 'default';
    protected $table                = 'promoteurs';
    protected $primaryKey           = 'promoteurID';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;
    protected $allowedFields        = [];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    public function __construct(){
        parent::__construct();
    }
    public static function ajouter(array $args = []):bool{
        $data = self::sanitize_for('promoteurs',$args);
        return db('promoteurs')
            ->insert($data);;
    }
    public static function modifier($primary_keys = null,array $data = []): bool
    {
        $data = self::sanitize_for('promoteurs',$data);
        return db('promoteurs')
            ->where('promoteurID',intval($primary_keys))
            ->update($data);;
    }
    public static function supprimer(mixed $primary_keys):bool{
        if(is_array($primary_keys)){
            return db('promoteurs')
                ->whereIn('promoteurID',$primary_keys)
                ->delete();;
        }else{
            return db('promoteurs')
                ->where('promoteurID',intval($primary_keys))
                ->delete();;
        }
    }
    public static function lister(){
        return db('promoteurs')
            ->get()
            ->getResult();;
    }
}
