<?php

namespace App\Modules\Api\Models;

use App\Controllers\IbemsModel;

class OrdonnanceModel extends IbemsModel
{
    protected $DBGroup              = 'default';
    protected $table                = 'ordonnances';
    protected $primaryKey           = 'ordonnanceID';
    protected $useAutoIncrement     = true;
    protected $insertID             = 0;
    protected $returnType           = 'array';
    protected $useSoftDelete        = false;
    protected $protectFields        = true;
    protected $allowedFields        = [
        "name",
        "email",
        "mobile"
    ];

    // Dates
    protected $useTimestamps        = false;
    protected $dateFormat           = 'datetime';
    protected $createdField         = 'created_at';
    protected $updatedField         = 'updated_at';
    protected $deletedField         = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks       = true;
    protected $beforeInsert         = [];
    protected $afterInsert          = [];
    protected $beforeUpdate         = [];
    protected $afterUpdate          = [];
    protected $beforeFind           = [];
    protected $afterFind            = [];
    protected $beforeDelete         = [];
    protected $afterDelete          = [];
    public function __construct(){
        parent::__construct();
    }
    public static function ajouter(array $args = []):bool{
        $medicament = request()->getVar('medicament');
        $quantite = request()->getVar('quantite');
        $posologie = request()->getVar('posologie');
        if(!is_array($medicament)||!is_array($quantite)||!is_array($posologie)) return false;
        db()->transStart();
        $data = self::sanitize_for('ordonnances',$args);
        $data['ordonnanceCode'] = bin2hex(random_bytes(4));
        $data['added'] = time();
        $data['added_by'] = get_user_info('user_id');
        db('ordonnances')->insert($data);
        $ordonnanceID = db()->insertID();
        $data = [];
        foreach ($medicament as $index=>$value){
            $data[]=[
                'ordonnanceID'=>$ordonnanceID,
                'medicamentCode'=>$value,
                'quantite'=>$quantite[$index],
                'posologie'=>$posologie[$index],
            ];
        }
        db('ordonnances_lignes')->insertBatch($data,true);
        db()->transComplete();
        return db()->transStatus() !== false;
    }
    public static function modifier(int $primary_keys,array $data = []): bool
    {
        $medicament = request()->getVar('medicament');
        $quantite = request()->getVar('quantite');
        $posologie = request()->getVar('posologie');
        if(!is_array($medicament)||!is_array($quantite)||!is_array($posologie)) return false;
        db()->transStart();
        $data = self::sanitize_for('ordonnances',$data);
        $data['ordonnanceCode'] = bin2hex(random_bytes(4));
        $data['added'] = time();
        $data['added_by'] = get_user_info('user_id');
        db('ordonnances')
            ->where('ordonnanceID',$primary_keys)
            ->update($data);
        $data = [];
        foreach ($medicament as $index=>$value){
            $data[]=[
                'ordonnanceID'=>$primary_keys,
                'medicamentCode'=>$value,
                'quantite'=>$quantite[$index],
                'posologie'=>$posologie[$index],
            ];
        }
        db('ordonnances_lignes')
            ->where('ordonnanceID',$primary_keys)
            ->delete();
        db('ordonnances_lignes')->insertBatch($data,true);
        db()->transComplete();
        return db()->transStatus() !== false;
    }
    public static function supprimer(int $primary_keys):bool{
        if($rs = self::trouver($primary_keys)){
            db()->transStart();
            db('ordonnances')
                ->where('ordonnanceID',intval($primary_keys))
                ->delete();
            db()->transComplete();
            return db()->transStatus() !== false;
        }
        return false;
    }
    public static function trouver(int $primary_key)
    {
        $rs = db('ordonnances')
            ->select("*,
                ordonnances.added AS create_at,
                CONCAT(doc.nom,' ',doc.prenoms) AS docteurNom,
                CONCAT(pat.nom,' ',pat.prenoms) AS patientNom")
            ->join('docteurs','docteurs.docteurID = ordonnances.docteurID','left')
            ->join('docteurs_personnes','docteurs_personnes.docteurID = docteurs.docteurID','left')
            ->join('personnes doc','doc.personneID = docteurs_personnes.personneID','left')
            ->join('patients','patients.patientID = ordonnances.patientID','left')
            ->join('personnes pat','pat.personneID = patients.personneID','left')
            ->get();
        if($rs){
            return $rs->getRow();
        }
        return false;
    }
    public static function lister()
    {
        $rs = db('ordonnances')
            ->select("*,
                ordonnances.added AS create_at,
                CONCAT(doc.nom,' ',doc.prenoms) AS docteurNom,
                CONCAT(pat.nom,' ',pat.prenoms) AS patientNom")
            ->join('docteurs','docteurs.docteurID = ordonnances.docteurID','left')
            ->join('docteurs_personnes','docteurs_personnes.docteurID = docteurs.docteurID','left')
            ->join('personnes doc','doc.personneID = docteurs_personnes.personneID','left')
            ->join('patients','patients.patientID = ordonnances.patientID','left')
            ->join('personnes pat','pat.personneID = patients.personneID','left')
            ->get();

        if($rs){
            return $rs->getResult();
        }
        return [];
    }
    public static function lignes($ordonnanceID)
    {
        $rs = db('ordonnances_lignes')
            ->select("*")
            ->join('medicaments','medicaments.medicamentCode = ordonnances_lignes.medicamentCode','left')
            ->where('ordonnanceID',intval($ordonnanceID))
            ->get();

        if($rs){
            return $rs->getResult();
        }
        return [];
    }
    public static function rechercherParCode(string $ordonnanceCode){
        if($rs =  db('ordonnances')
            ->where('ordonnanceCode',esc($ordonnanceCode))
            ->get()
        ){
            return $rs->getRow();
        }
        return false;
    }
}
